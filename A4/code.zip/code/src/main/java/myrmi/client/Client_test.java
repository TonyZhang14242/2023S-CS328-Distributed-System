package myrmi.client;

import myrmi.exception.NotBoundException;
import myrmi.exception.RemoteException;
import myrmi.registry.LocateRegistry;
import myrmi.registry.Registry;
import myrmi.server.MPI;

import java.util.Arrays;

public class Client_test {
    public static void main(String[] args) {
        Registry registry = LocateRegistry.getRegistry("Server",9000);
        try {
            System.out.println(Arrays.toString(registry.list()));
            MPI mpi = (MPI) registry.lookup("MPI");
            System.out.println(mpi.execution());
            System.out.println(mpi.executeMPI());
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        } catch (NotBoundException e) {
            throw new RuntimeException(e);
        }
    }
}
