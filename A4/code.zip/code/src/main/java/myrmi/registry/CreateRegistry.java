package myrmi.registry;

import myrmi.exception.RemoteException;

public class CreateRegistry {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.createRegistry(8000);
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
    }
}
