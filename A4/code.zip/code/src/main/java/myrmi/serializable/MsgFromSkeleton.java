package myrmi.serializable;

import java.io.Serializable;

public class MsgFromSkeleton implements Serializable {
    Object output;
    int status;
    public MsgFromSkeleton(Object output, int status)
    {
        this.output = output;
        this.status = status;
    }

    public MsgFromSkeleton(int status){
        this.status = status;
    };

    public MsgFromSkeleton(){

    }

    public Object getOutput() {
        return output;
    }

    public void setOutput(Object output) {
        this.output = output;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
