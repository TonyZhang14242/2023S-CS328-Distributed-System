package myrmi.serializable;

import java.io.Serializable;

public class MsgFromStub implements Serializable {
    String name;
    Object[] args;
    Class<?>[] ParameterTypes;
    int objectKey;
    public MsgFromStub(String name, Object[] args, int objectKey, Class<?>[] ParameterTypes) {
        this.name = name;
        if (args != null)
            this.args = args.clone();
        else
            this.args = null;
        this.objectKey = objectKey;
        this.ParameterTypes = ParameterTypes;
    }

    public String getName()
    {
        return name;
    }

    public Object[] getArgs(){
        return args;
    }

    public int getObjectKey() {
        return objectKey;
    }

    public Class<?>[] getParameterTypes() {
        return ParameterTypes;
    }

    public void setObjectKey(int objectKey) {
        this.objectKey = objectKey;
    }
}
