package myrmi.server;

import myrmi.Remote;

public interface MPI extends Remote {
    public String execution();

    public String executeMPI();
}
