package myrmi.server;

import myrmi.exception.RemoteException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MPIImpl extends UnicastRemoteObject implements MPI{
    protected MPIImpl() throws RemoteException {
    }

    protected MPIImpl(int port) throws RemoteException {
        super(port);
    }

    @Override
    public String execution() {
        return "Executed!!!!!!!!!!!!!!!!!!";
    }

    @Override
    public String executeMPI(){
        Runtime run = Runtime.getRuntime();
        StringBuilder output = new StringBuilder();
        try {
            Process p = run.exec("/mpiexe");// 启动另一个进程来执行命令
            BufferedInputStream in = new BufferedInputStream(p.getInputStream());
            BufferedReader inBr = new BufferedReader(new InputStreamReader(in));
            String lineStr;
            while ((lineStr = inBr.readLine()) != null){
                //System.out.println(lineStr);// 打印输出信息
                output.append(lineStr).append("\n");
            }

            //检查命令是否执行失败。
            if (p.waitFor() != 0) {
                if (p.exitValue() == 1)
                    System.err.println("命令执行失败!");
            }
            inBr.close();
            in.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        return output.toString();
    }
}
