package myrmi.server;

import myrmi.Remote;
import myrmi.exception.AlreadyBoundException;
import myrmi.exception.NotBoundException;
import myrmi.exception.RemoteException;
import myrmi.registry.LocateRegistry;
import myrmi.registry.Registry;



public class Server {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("Registry", 8000);
            Remote mpi = new MPIImpl();
            Registry stub = (Registry)UnicastRemoteObject.exportObject(registry, 9000);
            registry.bind("MPI", mpi);
            MPI test = (MPI) UnicastRemoteObject.exportObject(mpi, 8999);



        } catch (RemoteException e) {
            throw new RuntimeException(e);
        } catch (AlreadyBoundException e) {
            throw new RuntimeException(e);
        }

    }
}
