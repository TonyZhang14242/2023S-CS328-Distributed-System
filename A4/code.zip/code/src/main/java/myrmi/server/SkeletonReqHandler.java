package myrmi.server;

import myrmi.Remote;
import myrmi.serializable.MsgFromSkeleton;
import myrmi.serializable.MsgFromStub;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;

public class SkeletonReqHandler extends Thread {
    private Socket socket;
    private Remote obj;
    private int objectKey;

    public SkeletonReqHandler(Socket socket, Remote remoteObj, int objectKey) {
        this.socket = socket;
        this.obj = remoteObj;
        this.objectKey = objectKey;
    }

    @Override
    public void run() {
        int objectKey;
        String methodName;
        Class<?>[] argTypes;
        Object[] args;
        Object result;
        MsgFromSkeleton methodReturn = new MsgFromSkeleton();
        /*TODO: implement method here
         * You need to:
         * 1. handle requests from stub, receive invocation arguments, deserialization
         * 2. get result by calling the real object, and handle different cases (non-void method, void method, method throws exception, exception in invocation process)
         * Hint: you can use an int to represent the cases: -1 invocation error, 0 exception thrown, 1 void method, 2 non-void method
         *
         *  */
        try {
            InputStream inputStream = socket.getInputStream();
            ObjectInputStream bufferedReader = new ObjectInputStream(inputStream);
            MsgFromStub info;
            info = (MsgFromStub) bufferedReader.readObject();
//            System.out.println(info.getName() + " " + info.getArgs()[0] + " " + info.getObjectKey());
            objectKey = info.getObjectKey();
            //Method method = null; // = obj.getClass().getDeclaredMethod(info.getName(), argTypes);
            Method method = obj.getClass().getDeclaredMethod(info.getName(), info.getParameterTypes());
            if (info.getArgs() == null)
            {
                args = new Object[0];
            }
            else {
                args = info.getArgs();
            }
            if (method.getReturnType().equals(Void.TYPE))
            {
                methodReturn.setStatus(1);
                method.invoke(obj, args);
            }
            else {
                methodReturn.setStatus(2);
                methodReturn.setOutput(method.invoke(obj, args));
            }

            //System.out.println(((RegistryImpl) obj).lookup((String) info.getArgs()[0]));
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
//            System.out.println("write one out");
            objectOutputStream.writeObject(methodReturn);
            objectOutputStream.flush();

        } catch (IOException | ClassNotFoundException | IllegalAccessException | NoSuchMethodException e) {
            methodReturn.setStatus(0);
            methodReturn.setOutput(e);
            e.printStackTrace();
        }
        catch (InvocationTargetException e) {
            methodReturn.setStatus(-1);
            methodReturn.setOutput(e);
            e.printStackTrace();
        }

        ObjectOutputStream objectOutputStream = null;
        try {
            objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
//            System.out.println(socket);
            objectOutputStream.writeObject(methodReturn);
            objectOutputStream.flush();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
//            System.out.println(socket);
        }




        //System.out.println(socket.isConnected());
        //throw new NotImplementedException();

    }
}